import React, { useEffect, useState } from 'react';

export default function Dashboard() {
  const [data, setData] = useState(null);
  const [timestamp, setTimestamp] = useState(null);

  useEffect(() => {
    fetch('/api/conflict-dashboard.json')
      .then(res => res.json())
      .then(setData);
    setTimestamp(new Date().toLocaleString('en-IL', { timeZone: 'Asia/Jerusalem' }));
  }, []);

  if (!data) return <div>Loading...</div>;

  return (
    <div style={{ padding: 20, fontFamily: 'Arial, sans-serif' }}>
      <h1>Iran-Israel Conflict Dashboard</h1>
      <p>Last updated (Israel time): {timestamp}</p>

      <h2>Situation Summary</h2>
      <ul>{data.summary.map((item, i) => <li key={i}>{item}</li>)}</ul>

      <h2>Military Movements</h2>
      <ul>{data.military.map((item, i) => <li key={i}>{item}</li>)}</ul>

      <h2>Embassy Evacuations</h2>
      <table border="1" cellPadding="6">
        <thead>
          <tr><th>Country</th><th>Status</th><th>Notes</th></tr>
        </thead>
        <tbody>
          {data.evacuations.map((evac, i) => (
            <tr key={i}>
              <td>{evac.country}</td>
              <td>{evac.status}</td>
              <td>{evac.notes}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <h2>Live Alert Sources</h2>
      <ul>
        {data.alerts.map((src, i) => (
          <li key={i}><a href={src.link} target="_blank" rel="noreferrer">{src.name}</a></li>
        ))}
      </ul>
    </div>
  );
}
